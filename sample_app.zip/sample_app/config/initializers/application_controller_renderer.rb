# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '96d994d257eca61f3fb79630be3c50b76c4553a61d913a7cab1c5cb9317ce5f631a0d84443699eb3df5685abc44971d45079f1bd45721f960a6edf229f699510'